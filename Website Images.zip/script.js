

document.getElementById("nav01").innerHTML =


document.getElementById("foot01").innerHTML =
"<p>&copy;  " + new Date().getFullYear() + " TR Production. All rights reserved.</p>";


